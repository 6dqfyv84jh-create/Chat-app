package com.appusapp
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity: ComponentActivity(){ override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}} }
@Composable fun App(){
 var email by remember{mutableStateOf("")}; var pass by remember{mutableStateOf("")}; var ok by remember{mutableStateOf(FirebaseAuth.getInstance().currentUser!=null)}
 if(!ok) Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Center){
  Text("ChatApp",style=MaterialTheme.typography.headlineLarge); Spacer(Modifier.height(16.dp))
  OutlinedTextField(email,{email=it},label={Text("Email")},modifier=Modifier.fillMaxWidth())
  OutlinedTextField(pass,{pass=it},label={Text("Password")},modifier=Modifier.fillMaxWidth())
  Button({FirebaseAuth.getInstance().signInWithEmailAndPassword(email.trim(),pass).addOnSuccessListener{ok=true}},Modifier.fillMaxWidth()){Text("Sign in")}
  OutlinedButton({FirebaseAuth.getInstance().createUserWithEmailAndPassword(email.trim(),pass).addOnSuccessListener{ok=true}},Modifier.fillMaxWidth()){Text("Create account")}
 } else Chat()
}
@Composable fun Chat(){
 val db=FirebaseFirestore.getInstance(); var text by remember{mutableStateOf("")}; var msgs by remember{mutableStateOf(listOf<String>())}
 DisposableEffect(Unit){val l=db.collection("messages").orderBy("createdAt").addSnapshotListener{s,_->msgs=s?.documents?.mapNotNull{it.getString("text")}?:emptyList()};onDispose{l.remove()}}
 Column(Modifier.fillMaxSize().padding(16.dp)){Text("ChatApp",style=MaterialTheme.typography.headlineMedium);LazyColumn(Modifier.weight(1f)){items(msgs){Text(it,Modifier.padding(8.dp))}}
 Row{OutlinedTextField(text,{text=it},Modifier.weight(1f));Button({if(text.isNotBlank()){db.collection("messages").add(mapOf("text" to text,"createdAt" to System.currentTimeMillis()));text=""}}){Text("Send")}}}
}